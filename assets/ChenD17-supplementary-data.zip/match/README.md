This supplementary data contains the matching of WikiQA answer sentences to Concretely Annotated Wikipedia (CAW) data.

There are 3 files: {train|dev|test}-match.tsv -- each corresponding to the specific portion of the WikiQA dataset. Each file is a TSV file, where the column format is:

<WikiQA Sentence ID>    <CAW Article Title> <CAW Article Title:Section Number:Sentence Number>  <Sentence UUID> <Label>

